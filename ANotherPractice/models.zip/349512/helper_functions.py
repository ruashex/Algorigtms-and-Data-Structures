# Contains helper functions

import warnings
from math import sqrt

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pylab import rcParams
from sklearn.metrics import mean_squared_error

warnings.filterwarnings("ignore")


def initial_analysis_plots(list_series, list_names):
    """
    Makes plots for correlation checking.
    Input:  list_series: the list of series to be plotted
            list_names: variable names of the series
    Output: Plots the graphs.
    """
    for series in list_series:
        plt.plot(series)
    legend = []
    for list_name in list_names:
        legend.append('y = ' + list_name)
    plt.legend(legend, loc='upper left')
    plt.show()
    rcParams['figure.figsize'] = 18, 8


def get_number_of_steps_to_predict(submission, generic_lookup):
    """
    Returns the number of future data points for which the predictions are to be made.
    Input:  submission: the submission file
            generic_lookup: the generic llokup for which the predictions are to be made
    Output: the number of future time steps for which the predictions are to be made.
    """
    return submission[submission['Generic LookupKey'] == generic_lookup].shape[0]


def mean_absolute_percentage_error(y_true, y_pred):
    """
    Returns mean absolute percentage error
    """
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100


def max_absolute_percentage_error(y_true, y_pred):
    """
    Returns max absolute percentage error
    """
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.max(np.abs((y_true - y_pred) / y_true)) * 100


def rmse(y_true, y_pred):
    """
    Returns root mean square error
    """
    return sqrt(mean_squared_error(y_true, y_pred))


def split_train_test(df, column):
    """
    Split dataset into train and test dataframe.
    :param df: input dataframe
    :param column: feature column
    :return: train and test dataframes
    """
    first_index = df.apply(pd.Series.first_valid_index)[column]
    last_index = df.apply(pd.Series.last_valid_index)[column]

    train = pd.DataFrame()
    test = pd.DataFrame()

    train['Value'] = df[first_index:last_index][column]
    test['Value'] = df[last_index:][column].iloc[1:]

    train['Time Period'] = train.index
    test['Time Period'] = test.index

    train['Generic LookupKey'] = column
    test['Generic LookupKey'] = column

    return train, test


def read_excel(file):
    """
    Reads and prepares excel input file.
    :param file: input file path
    :return: dataframe
    """
    df = pd.read_excel(file)

    # select columns for prediction
    columns = ['Generic Variable']
    for c in df.columns:
        if '/' in c:
            columns.append(c)

    # transform dataframe
    dfc = df[columns]
    df_t = dfc.replace('x', np.nan).T
    df_t.columns = df_t.iloc[0]
    df_t = df_t.drop(df_t.index[0])

    df_t = df_t.astype(float)
    return df_t
