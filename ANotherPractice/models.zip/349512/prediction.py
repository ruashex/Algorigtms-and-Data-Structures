import argparse

import pandas as pd

import lstm_model as ltsm
import sarimax_model as srmx
from configuration import TARGET_VARIABLES, MODELS
from helper_functions import read_excel, split_train_test

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='The CFO Forecasting tool.')

    parser.add_argument('-i', '--input', dest='input_file', help='Input Excel file.', required=True)
    parser.add_argument('-o', '--output', dest='output_file', help='Output file.', required=True)

    args = parser.parse_args()

    print('Reading file')
    data = read_excel(args.input_file)
    print('Making full forecast')
    forecast_df = pd.DataFrame()
    for i, t in enumerate(TARGET_VARIABLES):
        print(t)
        train, test = split_train_test(data, t)

        train_exog = data[train.index[0]:train.index[-1]]
        test_exog = data[test.index[0]:test.index[-1]]

        if MODELS[t][0].startswith('LSTM'):
            history = 1
            units = 30

            params = MODELS[t][0].split('_')
            if len(params) > 1:
                history = params[1]
            if len(params) > 2:
                units = params[2]

            test['Value'] = ltsm.make_predictions(train, test, int(history), int(units))
        else:
            trend = None
            params = MODELS[t][0].split('_')
            if len(params) > 1:
                trend = params[1].lower()

            test['Value'] = srmx.make_predictions(train, test, None, test_exog, train_exog, trend)

        forecast_df = forecast_df.append(test)

    print('Save file')
    forecast_df.to_csv(args.output_file, index=False, header=True, columns=['Generic LookupKey', 'Time Period', 'Value'])
