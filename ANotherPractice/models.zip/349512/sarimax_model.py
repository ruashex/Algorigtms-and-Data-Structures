import itertools
import warnings

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm

from configuration import SHOW_PREDICTION_PLOT, MODELS, DEBUG_LOG
from helper_functions import rmse, mean_absolute_percentage_error, \
    max_absolute_percentage_error, get_number_of_steps_to_predict

warnings.filterwarnings("ignore")
plt.style.use('fivethirtyeight')

matplotlib.rcParams['axes.labelsize'] = 14
matplotlib.rcParams['xtick.labelsize'] = 12
matplotlib.rcParams['ytick.labelsize'] = 12
matplotlib.rcParams['text.color'] = 'k'


def best_parameters_sarimax(series, exog, trend):
    """
    Finds the best parameters for a given series for SARIMAX algorithm.
    Input: series: the series for which the parameters are to be determined.
    Output: the best parameters for the series and model.
    """
    result_param = -1
    result_param_seasonal = -1
    result_exog = None

    # p = [(0,1)]
    p = [1]
    d = q = range(0, 2)

    pdq = list(itertools.product(p, d, q))
    seasonal_pdq = [(x[0], x[1], x[2], 3) for x in list(itertools.product(p, d, q))]

    exog_list = [exog]
    minimum = np.inf
    for var_exog in exog_list:
        for param in pdq:
            for param_seasonal in seasonal_pdq:
                try:
                    results = apply_model_sarimax(series, param, param_seasonal, trend)

                    pred = results.predict()
                    rmse_val = rmse(series, pred)

                    if rmse_val < minimum:
                        result_param = param
                        result_param_seasonal = param_seasonal
                        minimum = results.aic
                        minimum = rmse_val
                except Exception as e:
                    print(e)
                    continue
    return result_param, result_param_seasonal


def apply_model_sarimax(series, best_param, best_param_seasonal, exog=None, trend=None):
    """
    Makes and trains SARIMAX model on the given series and parameters.
    Input:  series: series on which the model is to be trained.
            best_param, best_param_seasonal: best parameters for modelling
    Output: Trained model
    """
    mod = sm.tsa.statespace.SARIMAX(endog=series,
                                    order=best_param,
                                    seasonal_order=best_param_seasonal,
                                    enforce_stationarity=False,
                                    enforce_invertibility=False,
                                    trend=trend)
    results = mod.fit(disp=True)

    return results


def train_and_predict_sarimax(train, generic_lookup, validation_values, exog):
    """
    Train a SARIMAX and predicts on the validation data.
    Input:  train_df- training dataframe.
            generic_lookup- the generic_llokup for which we are going to predict.
            validation_values- the validation set to compare with.
    Output: The validation set RMSE value.
    """
    try:
        best_param, best_param_seasonal, best_exog = best_parameters_sarimax(
            train['Value'][train['Generic LookupKey'] == generic_lookup][:-5],
            validation_values, exog[:-5], exog[-5:].values.reshape(5, 1))

        results = apply_model_sarimax(train['Value'][train['Generic LookupKey'] == generic_lookup][:-5], best_param,
                                      best_param_seasonal, best_exog)

        if best_exog is not None:
            forecast = results.get_forecast(steps=5, exog=best_exog[-5:].values.reshape(5, 1))
        else:
            forecast = results.get_forecast(steps=5)

        mape_sarimax = mean_absolute_percentage_error(validation_values, forecast)
        return mape_sarimax
    except:
        return -1


def cross_validation_sarimax(train_df, train, number_of_steps_to_predict, generic_lookup,
                             validation_values, test_exog, train_exog, trend):
    """
    Compares the two model's validation RMSE values and returns the predictions for the best model.
    Input:  train_df- the dataframe of current generic lookup for training and prediction.
            train- full training dataframe.
            number_of_steps_to_predict- number of future steps to predict.
            validation_values- the validation set for comparison.
    Output: The final forecast for the current generic lookup.
    """

    train_series = train['Value'][train['Generic LookupKey'] == generic_lookup]
    best_param, best_param_seasonal = best_parameters_sarimax(train_series, train_exog, trend)

    best_exog = None

    if best_exog is not None:
        results = apply_model_sarimax(train['Value'][train['Generic LookupKey'] == generic_lookup], best_param,
                                      best_param_seasonal, train_exog, trend)
    else:
        results = apply_model_sarimax(train['Value'][train['Generic LookupKey'] == generic_lookup], best_param,
                                      best_param_seasonal, None, trend)

    if best_exog is not None:
        forecast = results.get_forecast(steps=number_of_steps_to_predict,
                                        exog=test_exog.values.reshape(len(test_exog), 1))
    else:
        forecast = results.get_forecast(steps=number_of_steps_to_predict)

    forecast = forecast.predicted_mean.tolist()

    if SHOW_PREDICTION_PLOT:
        validation_forecast = results.predict()
        validation_forecast = validation_forecast.values.tolist()

        forecast1 = results.get_forecast(steps=number_of_steps_to_predict + 1)
        forecast1 = forecast1.predicted_mean.tolist()

        validation_forecast.append(forecast1[0])
        validation_forecast = validation_forecast[1:]
        forecast1 = forecast1[1:]

        predictions = pd.DataFrame(validation_forecast)
        predictions.reset_index(drop=True, inplace=True)
        predictions.index = train_df.index
        predictions['Actual'] = train_df[generic_lookup]
        predictions.rename(columns={0: 'Pred'}, inplace=True)
        predictions['Actual'].plot(figsize=(20, 8), legend=True, color='blue')

        history1 = predictions['Pred'].append(pd.Series(forecast1), ignore_index=True)
        history1.plot(legend=True, color='green', figsize=(20, 8), label='Forecast')
        predictions['Pred'].plot(legend=True, color='red', figsize=(20, 8))

        validation_mape_sarimax = mean_absolute_percentage_error(
            train['Value'][train['Generic LookupKey'] == generic_lookup], validation_forecast)
        validation_mxape_sarimax = max_absolute_percentage_error(
            train['Value'][train['Generic LookupKey'] == generic_lookup], validation_forecast)

        validation_rmse = rmse(train['Value'][train['Generic LookupKey'] == generic_lookup], validation_forecast)

        plt.title(f'{generic_lookup} {MODELS[generic_lookup]}\nMAPE={validation_mape_sarimax} MaxAPE={validation_mxape_sarimax} RMSE={validation_rmse} params={best_param} {best_param_seasonal}')
        matplotlib.rcParams['figure.figsize'] = 18, 8
        plt.show()

        if DEBUG_LOG:
            tag = 'Debug'

            f = open(f'logs/{generic_lookup.replace(" ", "-")}.log', mode='a')
            f.write(f'{tag:>15}:{generic_lookup} {str(MODELS[generic_lookup]):<10} MAPE={validation_mape_sarimax:.3f} MaxAPE={validation_mxape_sarimax:.3f} RMSE={validation_rmse:.3f} params={best_param} {best_param_seasonal}\n')
            f.close()

    return forecast


def cross_validation_and_model_comparison(train_df, train, number_of_steps_to_predict, generic_lookup,
                                          validation_values):
    """
    Compares the two model's validation RMSE values and returns the predictions for the best model.
    Input:  train_df- the dataframe of current generic lookup for training and prediction.
            train- full training dataframe.
            number_of_steps_to_predict- number of future steps to predict.
            validation_values- the validation set for comparison.
    Output: The final forecast for the current generic lookup.
    """

    # Check validation RMSE for both the models
    validation_rmse_sarimax = train_and_predict_sarimax(train, generic_lookup, validation_values)

    best_param, best_param_seasonal = best_parameters_sarimax(
        train['Value'][train['Generic LookupKey'] == generic_lookup])
    results = apply_model_sarimax(train['Value'][train['Generic LookupKey'] == generic_lookup], best_param,
                                  best_param_seasonal)
    forecast = results.get_forecast(steps=number_of_steps_to_predict)
    forecast = forecast.predicted_mean.tolist()
    return forecast


def make_predictions(train, test, related_features, test_exog, train_exog, trend):
    """
    The parent function to join correlated features, get number of steps, does cross validation and compares models.
    Input:  submission: submission dataframe.
            train: train dataframe.
            related_features: dictionary of related features.
    Output: Full forecast for all the generic lookup.
    """
    # Initialize a list for all generic lookup.
    full_forecast = []

    # For every generic lookup in submission.
    for generic_lookup in test['Generic LookupKey'].unique():

        train_df = pd.DataFrame()
        series_data = train['Value'][train['Generic LookupKey'] == generic_lookup].tolist()
        train_df[generic_lookup] = series_data

        # Get number of steps to predict for this generic lookup
        number_of_steps_to_predict = get_number_of_steps_to_predict(test, generic_lookup)

        # Take last 5 as validation
        validation_values = train_df[generic_lookup][-5:]

        # Check cross validation and do final prediction.
        forecast = cross_validation_sarimax(train_df, train, number_of_steps_to_predict, generic_lookup,
                                            validation_values, test_exog, train_exog, trend)
        if forecast == -1:
            forecast = [train_df[generic_lookup].mean()] * number_of_steps_to_predict
        full_forecast += forecast

    return full_forecast
