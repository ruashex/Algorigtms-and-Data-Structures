import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import rcParams
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import LSTM
from tensorflow.keras.models import Sequential

from configuration import SHOW_PREDICTION_PLOT, MODELS, DEBUG_LOG
from helper_functions import get_number_of_steps_to_predict, mean_absolute_percentage_error, \
    max_absolute_percentage_error, rmse


def create_dataset(dataset, look_back=1):
    """Creates dataset"""
    data_x, data_y = [], []
    for i in range(len(dataset) - look_back):
        a = dataset[i:(i + look_back), 0]
        data_x.append(a)
        data_y.append(dataset[i + look_back, 0])
    return np.array(data_x), np.array(data_y)


def make_predictions(train, test, history=1, units=30, scale=False):
    """
    The parent function to join correlated features, get number of steps, does cross validation and compares models.
    Input:  submission: submission dataframe.
            train: train dataframe.
            related_features: dictionary of related features.
    Output: Full forecast for all the generic lookup.
    """
    # Initialize a list for all generic lookup.
    full_forecast = []

    # For every generic lookup in submission.
    for generic_lookup in test['Generic LookupKey'].unique():

        train_df = pd.DataFrame()
        series_data = train['Value'][train['Generic LookupKey'] == generic_lookup].tolist()
        train_df[generic_lookup] = series_data

        # Get number of steps to predict for this generic lookup
        number_of_steps_to_predict = get_number_of_steps_to_predict(test, generic_lookup)

        scaler = MinMaxScaler(feature_range=(0, 1))

        dataset = train_df.values if not scale else scaler.fit_transform(train_df)

        train_x, train_y = create_dataset(dataset, history)

        train_x = np.reshape(train_x, (train_x.shape[0], 1, train_x.shape[1]))

        # create and fit the LSTM network
        model = Sequential()
        model.add(LSTM(units=units, return_sequences=True, input_shape=(1, history)))
        model.add(Dropout(0.2))
        model.add(LSTM(units=units, return_sequences=True))
        model.add(Dropout(0.1))
        model.add(LSTM(units=units))
        model.add(Dense(1))
        model.compile(loss='mean_squared_error', optimizer='adam') 

        model.fit(train_x, train_y, epochs=300, batch_size=20, verbose=2)

        test_x = np.array([train_y[-history:]])
        forecast = []

        for i in range(0, number_of_steps_to_predict):  # + history):
            test_x = np.reshape(test_x, (test_x.shape[0], 1, history))
            test_predict = model.predict(test_x)

            test_x = np.roll(test_x, -1)
            test_x[0][0][history - 1] = test_predict[0][0]

            output = test_predict if not scale else scaler.inverse_transform(test_predict)

            forecast.append(output[0][0])

        test_x = np.array([train_x[0]])
        predict = []

        for i in range(0, len(train_x)):
            test_predict = model.predict(np.reshape(train_x[i], (test_x.shape[0], 1, history)))
            output = test_predict if not scale else scaler.inverse_transform(test_predict)

            predict.append(output[0][0])

        if SHOW_PREDICTION_PLOT:
            validation_forecast = predict

            forecast1 = forecast

            predictions = pd.DataFrame(validation_forecast)
            predictions.reset_index(drop=True, inplace=True)
            predictions.index = train_df.index[:-history]
            predictions['Actual'] = train_df[generic_lookup][:-history]
            predictions.rename(columns={0: 'Pred'}, inplace=True)
            predictions['Actual'].plot(figsize=(20, 8), legend=True, color='blue')

            history1 = predictions['Pred'].append(pd.Series(forecast1), ignore_index=True)
            history1.plot(legend=True, color='green', figsize=(20, 8), label='Forecast')
            predictions['Pred'].plot(legend=True, color='red', figsize=(20, 8))

            validation_mape_sarimax = mean_absolute_percentage_error(
                train['Value'][train['Generic LookupKey'] == generic_lookup][:-history], validation_forecast)
            validation_mxape_sarimax = max_absolute_percentage_error(
                train['Value'][train['Generic LookupKey'] == generic_lookup][:-history], validation_forecast)

            validation_rmse = rmse(train['Value'][train['Generic LookupKey'] == generic_lookup][:-history],
                                   validation_forecast)

            best_param = 0
            best_param_seasonal = 0

            plt.title(f'{generic_lookup} {MODELS[generic_lookup]}\nMAPE={validation_mape_sarimax} MaxAPE={validation_mxape_sarimax} RMSE={validation_rmse} params={best_param} {best_param_seasonal}')

            rcParams['figure.figsize'] = 18, 8
            plt.show()

            if DEBUG_LOG:
                tag = 'Debug'

                f = open(f'logs/{generic_lookup.replace(" ", "-")}.log', mode='a')
                f.write(f'{tag:>15}:{generic_lookup} {str(MODELS[generic_lookup]):<10} MAPE={validation_mape_sarimax:.3f} MaxAPE={validation_mxape_sarimax:.3f} RMSE={validation_rmse:.3f} params={best_param} {best_param_seasonal}\n')
                f.close()

        if forecast == -1:
            forecast = [train_df[generic_lookup].mean()] * number_of_steps_to_predict
        full_forecast += forecast

    return full_forecast
