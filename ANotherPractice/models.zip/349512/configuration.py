# Configurable parameters

# Make True to see model prediction graphs
SHOW_PREDICTION_PLOT = False

# Make True to save logs
DEBUG_LOG = False

# Generic variables to forecasting
TARGET_VARIABLES = [
    'Average revenue per existing customer  - Tortoise',
    'Average Revenue per existing customer Excl Line Rental - Falcon',
    'Leavers - Tortoise',
    'Churn - Falcon',
    'Closing Base - Tortoise',
    'Closing Base - Falcon',
    'Gross Adds - Tortoise',
    'Gross Adds - Falcon',
    'Net Migrations - Tortoise',
    'Net Migrations - Falcon',
    'Revenue - Tortoise',
    'Revenue - Falcon'
]

# Models and thresholds(info only) for variables
MODELS = {
    'Average revenue per existing customer  - Tortoise': ('SARIMAX', 1012, 1117, 223),
    'Average Revenue per existing customer Excl Line Rental - Falcon': ('SARIMAX', 1401, 1144, 229),
    'Leavers - Tortoise': ('LSTM_3_25', 104, 91, 45),
    'Churn - Falcon': ('LSTM_3_100', 55, 54, 22),
    'Closing Base - Tortoise': ('SARIMAX', 7, 10, 5),
    'Closing Base - Falcon': ('SARIMAX', 3, 13, 3),
    'Gross Adds - Tortoise': ('LSTM_3_128', 112, 58, 23),
    'Gross Adds - Falcon': ('LSTM_3_50', 45, 41, 27),
    'Net Migrations - Tortoise': ('LSTM_5', 196, 206, 69),
    'Net Migrations - Falcon': ('LSTM_5', 178, 196, 65),
    'Revenue - Tortoise': ('LSTM_1_60', 196, 206, 69),
    'Revenue - Falcon': ('SARIMAX_CT', 24, 42, 8)
}
